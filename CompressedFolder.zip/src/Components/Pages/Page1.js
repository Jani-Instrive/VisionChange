import React from 'react'
import './Page1.css'

const Page1 = () => {
  return (
    <div className='MainBox'>
        <div className='MainDiv'>
            <h1>Page-1</h1>
        </div>
    </div>
  )
}

export default Page1