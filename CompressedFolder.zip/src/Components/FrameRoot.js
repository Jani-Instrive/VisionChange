import React from "react";
import styled from "styled-components";
import "./FrameRoot.css"
import { Grid } from "@mui/material";
import Navbar2 from '../Components/Navbar/Navbar2';

const FrameRootRoot1 = ({}) => {
  return (
    <FrameRootRootRoot className="FrameRootRootRoot">
    {/* <Navbar/> */}
    <div>
      <Navbar2/>
    </div>
      <MainHero className="MainHero">
          <LeftContainer className="LeftContainer">
            <HeaderText1 className = 'header1'>
              One Identity, <br />
              One Wallet,
              <br />
              One Ecosystem
            </HeaderText1>
            
              <Paragraph className="paragraph">
                ProxteraOne is the unified identity solution that empowers
                businesses for B2B cross-border trade.{" "}
              </Paragraph>
              <SignColumn className="SignColumn">
                <RedSignColumn className="RedSignColumn">
                  <SignText className="SignText">Sign Up / Login</SignText>
                </RedSignColumn>
              </SignColumn>
            <Left_Bottom1 className="Left_Bottom1" >
              <Left_Bottom_Columns className="Left_Bottom_Columns">
                <Text3 className="text3">SMEs Enabled</Text3>
                <Text4 className="text4">400,000+</Text4>
              </Left_Bottom_Columns>
              <Left_Bottom_Columns2 className="Left_Bottom_Columns2">
                <Text5>Markeplace Partners</Text5>
                <Text4 className="text4">18</Text4>
              </Left_Bottom_Columns2>
              <Left_Bottom2 className="Left_Bottom2">
                <FlexColumn5 className="FlexColumn5">
                  <Text7 className="text7">Countries Connected</Text7>
                  <Text4 className="text4">7</Text4>
                </FlexColumn5>
                <Left_Bottom_Columns className="Left_Bottom_Columns">
                  <Text9 className="text9">Payment Providers</Text9>
                  <Text4 className="text4">6</Text4>
                </Left_Bottom_Columns>
              </Left_Bottom2>
            </Left_Bottom1>
          </LeftContainer>
        <RightContainer className="RightContainer">
        <iframe src='https://my.spline.design/iphone13copy-55d48947b02cb89a00b5d31a29ee79f3/' frameborder='0' overflow= 'visible' width='100%' height='100%'></iframe>
        </RightContainer>
      </MainHero>
    </FrameRootRootRoot>
  );
};

export default FrameRootRoot1;


const Left_Bottom_Columns = styled.div`
  position: relative;
  min-widt:10px;
  gap: 0px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  font-family: Open Sans;
  align-items: center;
  // box-shadow: 0px 4px 4px 0px rgba(255, 255, 255, 0.4);
`;

const FrameRootRootRoot = styled.div`

`;

const HeaderText1 = styled.div`

`;
const Paragraph = styled.div`
  
`;
const SignColumn = styled.div`

`;
const RedSignColumn = styled.div`
`;
const SignText = styled.div`

`;

const Text3 = styled.div`
  width: 136px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 24px;
  font-family: Open Sans;
  text-align: center;
`;
const Left_Bottom_Columns2 = styled.div`
  left: 194px;
  top: 0px;
  position: absolute;
  gap: 0px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  // box-shadow: 0px 4px 4px 0px rgba(255, 255, 255, 0.4);
`;


const FlexColumn5 = styled.div`
  left: 0px;
  top: 0px;
  position: absolute;
  gap: 0px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  // box-shadow: 0px 4px 4px 0px rgba(255, 255, 255, 0.4);
`;
const Text4 = styled.div`
  color: #ffffff;
  font-size: 48px;
  font-weight: 700;
  font-family: Open Sans;
  white-space: nowrap;
`;
const Text5 = styled.div`
  max-width: 166px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 24px;
  font-family: Open Sans;
  text-align: center;
`;
const Text7 = styled.div`
  max-width: 191px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 24px;
  font-family: Open Sans;
  text-align: center;
`;
const Text9 = styled.div`
  max-width: 150px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 24px;
  font-family: Open Sans;
  text-align: center;
`;
const MainHero = styled.div`
`;
const LeftContainer = styled.div`
  
`;
const Left_Bottom1 = styled.div`

`;
const Left_Bottom2 = styled.div`

`;

const RightContainer = styled.div`

`;
